NAOPLD Lab Technician Evaluation - LabWare LIMS Pack

This pack gives you the DB view templates + Power Query scripts to create a PBIX fast.

1) Create an Employee mapping (LabWare user -> EmployeeID).
2) Create vw_NAOPLD_TechMonthlyKPI in a reporting schema/replica (Oracle or SQL Server).
3) In Power BI Desktop:
   - Create parameters (server/db/schema/view)
   - Paste the M script (SQL Server or Oracle) into a new query called FactPerformanceMonthly
   - Add DimEmployee, DimDate, Targets, SecurityUserEmployee
   - Create relationships + DAX measures (use your DAX pack)
   - Configure RLS using USERPRINCIPALNAME()
4) Publish PBIX to a Workspace -> Configure Gateway + Scheduled Refresh -> Create Power BI App.

Refresh: Requires On-premises data gateway for on-prem DB sources.
