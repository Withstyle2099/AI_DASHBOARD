/* NAOPLD Lab Technician Evaluation - LabWare LIMS (SQL Server) VIEW TEMPLATE
   Output columns (Technician x Month):
   EmployeeID, MonthStart, TestsCount, OnTimePct, QC_PassPct, ReworkCount,
   NC_Count, CAPA_OverdueCount, TrainingHours, SafetyObsCount, IncidentCount, CI_Count, Comments

   Replace table/column names to match your LabWare schema.
*/
CREATE OR ALTER VIEW dbo.vw_NAOPLD_TechMonthlyKPI
AS
WITH Base AS (
    SELECT
        m.EmployeeID,
        DATEFROMPARTS(YEAR(r.ReportedDate), MONTH(r.ReportedDate), 1) AS MonthStart,
        COUNT(*) AS TestsCount,
        SUM(CASE WHEN DATEDIFF(HOUR, r.ReceivedDate, r.ReportedDate) <= r.TATHours THEN 1 ELSE 0 END) * 1.0
            / NULLIF(COUNT(*),0) AS OnTimePct,
        SUM(CASE WHEN r.QCFlag = 1 AND r.QCStatus = 'PASS' THEN 1 ELSE 0 END) * 1.0
            / NULLIF(SUM(CASE WHEN r.QCFlag = 1 THEN 1 ELSE 0 END),0) AS QC_PassPct,
        SUM(CASE WHEN r.IsRerun = 1 THEN 1 ELSE 0 END) AS ReworkCount
    FROM dbo.LW_Results r
    INNER JOIN dbo.LW_EmployeeMap m
        ON r.AnalystUser = m.LabWareUser
    WHERE r.ReportedDate IS NOT NULL
    GROUP BY
        m.EmployeeID,
        DATEFROMPARTS(YEAR(r.ReportedDate), MONTH(r.ReportedDate), 1)
),
Extras AS (
    SELECT
        EmployeeID,
        MonthStart,
        CAST(0 AS int) AS NC_Count,
        CAST(0 AS int) AS CAPA_OverdueCount,
        CAST(0 AS decimal(10,2)) AS TrainingHours,
        CAST(0 AS int) AS SafetyObsCount,
        CAST(0 AS int) AS IncidentCount,
        CAST(0 AS int) AS CI_Count,
        CAST(NULL AS nvarchar(4000)) AS Comments
    FROM Base
)
SELECT
    b.EmployeeID,
    b.MonthStart,
    b.TestsCount,
    b.OnTimePct,
    b.QC_PassPct,
    b.ReworkCount,
    e.NC_Count,
    e.CAPA_OverdueCount,
    e.TrainingHours,
    e.SafetyObsCount,
    e.IncidentCount,
    e.CI_Count,
    e.Comments
FROM Base b
LEFT JOIN Extras e
    ON b.EmployeeID = e.EmployeeID AND b.MonthStart = e.MonthStart;
