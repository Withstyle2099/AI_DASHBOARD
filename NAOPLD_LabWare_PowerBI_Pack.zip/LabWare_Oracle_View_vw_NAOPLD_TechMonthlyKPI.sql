/* NAOPLD Lab Technician Evaluation - LabWare LIMS (Oracle) VIEW TEMPLATE
   Output columns (Technician x Month):
   EmployeeID, MonthStart, TestsCount, OnTimePct, QC_PassPct, ReworkCount,
   NC_Count, CAPA_OverdueCount, TrainingHours, SafetyObsCount, IncidentCount, CI_Count, Comments

   Replace table/column names to match your LabWare schema.
*/
CREATE OR REPLACE VIEW vw_NAOPLD_TechMonthlyKPI AS
WITH Base AS (
    SELECT
        m.EmployeeID,
        TRUNC(r.ReportedDate, 'MM') AS MonthStart,
        COUNT(*) AS TestsCount,
        SUM(CASE WHEN (r.ReportedDate - r.ReceivedDate) * 24 <= r.TATHours THEN 1 ELSE 0 END) / NULLIF(COUNT(*),0) AS OnTimePct,
        SUM(CASE WHEN r.QCFlag = 1 AND r.QCStatus = 'PASS' THEN 1 ELSE 0 END)
          / NULLIF(SUM(CASE WHEN r.QCFlag = 1 THEN 1 ELSE 0 END),0) AS QC_PassPct,
        SUM(CASE WHEN r.IsRerun = 1 THEN 1 ELSE 0 END) AS ReworkCount
    FROM LW_RESULTS r
    JOIN LW_EMPLOYEEMAP m
      ON r.AnalystUser = m.LabWareUser
    WHERE r.ReportedDate IS NOT NULL
    GROUP BY m.EmployeeID, TRUNC(r.ReportedDate, 'MM')
),
Extras AS (
    SELECT
        EmployeeID,
        MonthStart,
        0 AS NC_Count,
        0 AS CAPA_OverDUECount,
        0 AS TrainingHours,
        0 AS SafetyObsCount,
        0 AS IncidentCount,
        0 AS CI_Count,
        CAST(NULL AS VARCHAR2(4000)) AS Comments
    FROM Base
)
SELECT
    b.EmployeeID,
    b.MonthStart,
    b.TestsCount,
    b.OnTimePct,
    b.QC_PassPct,
    b.ReworkCount,
    e.NC_Count,
    e.CAPA_OverDUECount AS CAPA_OverdueCount,
    e.TrainingHours,
    e.SafetyObsCount,
    e.IncidentCount,
    e.CI_Count,
    e.Comments
FROM Base b
LEFT JOIN Extras e
  ON b.EmployeeID = e.EmployeeID AND b.MonthStart = e.MonthStart;
